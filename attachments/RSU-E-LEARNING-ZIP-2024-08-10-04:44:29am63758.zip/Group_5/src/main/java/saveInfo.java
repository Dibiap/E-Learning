

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class saveInfo
 */
public class saveInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter pw = response.getWriter();
		pw.println("Patient Record System.");
		pw.println("New Entry");
		pw.println("---------");
		pw.println("NationalID: " + request.getParameter("NationalID"));
		pw.println("FirstName: " + request.getParameter("FirstName"));
		pw.println("LastName: " + request.getParameter("LastName"));
		pw.println("Gender: " + request.getParameter("gender"));
		pw.println("Mobile: " + request.getParameter("Mobile"));
		pw.println("Telephone: " + request.getParameter("Telephone"));
		pw.println("Email: " + request.getParameter("Email"));
		pw.println("Age: " + request.getParameter("Age"));
		pw.println("MaritalStatus: " + request.getParameter("maritalStatus"));
		pw.println("Dob: " + request.getParameter("dob"));
		pw.println("Bloodtype: " + request.getParameter("bloodtype"));
		pw.println("Doctor: " + request.getParameter("doctor"));
		pw.println("Country: " + request.getParameter("country"));
		pw.println("City: " + request.getParameter("city"));
		pw.println("Village: " + request.getParameter("village"));
		pw.println("Street: " + request.getParameter("street"));
		pw.println("Nationality: " + request.getParameter("nationality"));
		pw.println("Image: " + request.getParameter("image"));
		pw.println("Contact Type: " + request.getParameter("type"));
		pw.println("Patient Contact Details: " + request.getParameter("Details"));
		pw.close();
	}
}
